from django.template import Library

register = Library()

def space2dash(s):
    return s.replace(' ', '_')

register.filter(space2dash)