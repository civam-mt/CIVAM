from django.contrib import admin
from .models import subscriber
# Register your models here.

admin.site.site_header = "360VR Technology"
admin.site.site_title = "Admin Portal"
admin.site.index_title = "Welcome to Admin Interface"


class subscriberAdmin(admin.ModelAdmin):
    list_display = ['subscriber_email', 'created']
    list_display_links = ['subscriber_email']

admin.site.register(subscriber,subscriberAdmin)