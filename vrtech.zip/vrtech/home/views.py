from django.shortcuts import render
from django.views.decorators.gzip import gzip_page
from .models import subscriber
# Create your views here.

@gzip_page
def index(request):
    if request.method == "POST":
        subscriber_email = request.POST['email']
        print(subscriber_email)
        if subscriber.objects.filter(subscriber_email=subscriber_email).first():
            context = {'msg': 'You are already registered.'}
            return render(request, 'home/index.html', context)
        else:
            subscriber_model = subscriber(subscriber_email=subscriber_email)
            subscriber_model.save()
            context = {'msg':'You are registered as subscriber sucessfully.'}
            return render(request, 'home/index.html', context)
    return render(request, 'home/index.html')


@gzip_page
def subscribe(request):
    if request.method == "POST":
        subscriber_email = request.POST['email_subscribe']
        print(subscriber_email)
        if subscriber.objects.filter(subscriber_email=subscriber_email).first():
            context = {'msg_subscribe': 'You are already registered.'}
            return render(request, 'home/index.html', context)
        else:
            subscriber_model = subscriber(subscriber_email=subscriber_email)
            subscriber_model.save()
            context = {'msg_subscribe':'You are registered as subscriber sucessfully.'}
            return render(request, 'home/index.html', context)


@gzip_page
def terms(request):
    return render(request, 'home/terms_conditions.html')

@gzip_page
def privacy(request):
    return render(request, 'home/privacy_policy.html')
