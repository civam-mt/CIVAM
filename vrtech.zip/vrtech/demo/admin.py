from django.contrib import admin
from .models import demo_request
# Register your models here.

class demo_requestAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'org_name', 'msg', 'created']

admin.site.register(demo_request,demo_requestAdmin)
