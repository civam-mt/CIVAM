from django.shortcuts import render, HttpResponse
from django.http import HttpResponseRedirect
from .models import demo_request
from django.core.mail import send_mail
from django.views.decorators.gzip import gzip_page
# Create your views here.

@gzip_page
def demo(request):
    if request.method == "POST":
        name = request.POST['name']
        org_name = request.POST['org_name']
        email = request.POST['email']
        msg = request.POST['message']
        demo_model = demo_request(name = name, email = email, org_name = org_name, msg = msg)
        demo_model.save()
        email_subject = 'Query from '+ name
        email_msg = msg + '\n From ... ' + email
        from_email = 'soutshrama@gmail.com'
        to_email = 'rahul.sadtm@gmail.com'
        # send_mail(email_subject, email_msg, from_email, [to_email], fail_silently=False)
        context = {'submit_response' : 'Your Query submitted successfully. Our team will contact you within 24 Hrs.'}
        return render(request, 'demo/demo.html', context)
    else:
        return render(request, 'demo/demo.html', {})


