from django.shortcuts import render
from django.views.decorators.gzip import gzip_page
# Create your views here.

@gzip_page
def our_platform(request):
    return render(request, 'our_platform/platform.html')
