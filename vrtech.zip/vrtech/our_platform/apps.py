from django.apps import AppConfig


class OurPlatformConfig(AppConfig):
    name = 'solutions'
