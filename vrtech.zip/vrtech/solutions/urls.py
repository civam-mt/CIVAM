from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'commercial/', views.commercial),
    url(r'academic/', views.academic),
    url(r'critical_infrastructure/', views.critical_infrastructure),
    url(r'defense/', views.defense),
    url(r'insurance/', views.insurance),
    url(r'iotai/', views.iotai),
]
