from django.shortcuts import render
from django.views.decorators.gzip import gzip_page
# Create your views here.

@gzip_page
def commercial(request):
    return render(request, 'solutions/commercial.html')

@gzip_page
def academic(request):
    return render(request, 'solutions/academic.html')

@gzip_page
def critical_infrastructure(request):
    return render(request, 'solutions/critical_infra.html')

@gzip_page
def defense(request):
    return render(request, 'solutions/defense.html')

@gzip_page
def insurance(request):
    return render(request, 'solutions/insurance.html')

@gzip_page
def iotai(request):
    return render(request, 'solutions/iotai.html')