from django.apps import AppConfig


class SolutionsConfig(AppConfig):
    name = 'solutions'
