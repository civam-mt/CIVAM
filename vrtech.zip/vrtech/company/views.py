from django.shortcuts import render
from django.views.decorators.gzip import gzip_page
# Create your views here.

@gzip_page
def team(request):
    return render(request, 'company/team.html')
