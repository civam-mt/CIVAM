from django.shortcuts import render
from django.views.decorators.gzip import gzip_page
from django.core.paginator import Paginator, EmptyPage, InvalidPage
from .models import press
from django.db.models import Q
# Create your views here.

@gzip_page
def press_view(request):
    if request.method == 'POST':
        query = request.POST['search_query']
        news_display = press.objects.all().filter(Q(news_heading__icontains=query) | Q(news_content__icontains=query))
        context = {'news_all': news_display}
    else:
        news_display = press.objects.all().order_by('-posted_on')
        paginator = Paginator(news_display, 4)
        try:
            page = int(request.GET.get('page', '1'))
        except:
            page = 1
        try:
            news_display = paginator.page(page)
        except(EmptyPage, InvalidPage):
            news_display = paginator.page(paginator.num_pages)
        print('news-display : ', news_display)
        context = {'news_all': news_display}

    return render(request, 'press/press.html', context)
