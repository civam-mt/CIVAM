from django.db import models

# Create your models here.
class press(models.Model):
    image = models.ImageField(upload_to='press_image')
    news_heading = models.CharField(max_length=100)
    news_content = models.TextField()
    published_by = models.CharField(max_length=50)
    news_url = models.CharField(max_length=100)
    posted_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return '{} {} {} {} {}'.format(self.image, self.news_heading, self.news_content, self.published_by, self.news_url, self.posted_on)
