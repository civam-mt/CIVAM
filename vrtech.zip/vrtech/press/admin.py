from django.contrib import admin
from .models import press
# Register your models here.

class pressAdmin(admin.ModelAdmin):
    list_display = ['image', 'news_heading', 'published_by', 'news_content', 'news_url', 'posted_on']
    list_display_links = ['news_heading']

admin.site.register(press,pressAdmin)
